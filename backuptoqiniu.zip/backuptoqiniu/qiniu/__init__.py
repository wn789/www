'''
Qiniu Resource Storage SDK for Python
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For detailed document, please see:
<https://github.com/qiniu/python-sdk/blob/develop/docs/README.md>
'''

# -*- coding: utf-8 -*-
__version__ = '6.1.3'
